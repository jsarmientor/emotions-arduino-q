const video = document.getElementById('video');
const currentExpressionSpan = document.getElementById('current-expression');

// Mapeo de expresiones de face-api.js a los textos y emojis de la interfaz
const expressionsMap = {
    happy: { emoji: '😃', text: 'Feliz', btnId: 'btn-feliz' },
    sad: { emoji: '😢', text: 'Triste', btnId: 'btn-triste' },
    neutral: { emoji: '😐', text: 'Neutral', btnId: 'btn-neutral' },
    angry: { emoji: '😡', text: 'Enojado', btnId: 'btn-enojado' },
    surprised: { emoji: '😲', text: 'Sorprendido', btnId: null },
    disgusted: { emoji: '🤢', text: 'Disgustado', btnId: null },
    fearful: { emoji: '😨', text: 'Temeroso', btnId: null }
};

// Cargar modelos de face-api
async function loadModels() {
    try {
        currentExpressionSpan.innerText = "Cargando modelos...";
        await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri('./models'),
            faceapi.nets.faceExpressionNet.loadFromUri('./models')
        ]);
        currentExpressionSpan.innerText = "Iniciando cámara...";
        startVideo();
    } catch (e) {
        console.error("Error al cargar modelos:", e);
        currentExpressionSpan.innerText = "Error al cargar modelos. (Asegúrate de ejecutar con un servidor local)";
    }
}

// Iniciar webcam
function startVideo() {
    navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
        .then(stream => {
            video.srcObject = stream;
        })
        .catch(err => {
            console.error("Error al acceder a la cámara:", err);
            currentExpressionSpan.innerText = "Sin acceso a cámara";
        });
}

let lastExpression = null;
let noFaceFrames = 0;

// Escuchar evento play del video
video.addEventListener('play', () => {
    currentExpressionSpan.innerText = "Detectando...";
    
    // Intervalo de detección
    setInterval(async () => {
        // Detectar cara y expresiones (con TinyFaceDetector por rendimiento)
        const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withFaceExpressions();
        
        if (detections.length > 0) {
            noFaceFrames = 0; // Reiniciar contador de pérdida
            const expressions = detections[0].expressions;
            
            // Obtener la expresión con mayor probabilidad (dominante)
            const dominant = Object.keys(expressions).reduce((a, b) => expressions[a] > expressions[b] ? a : b);
            
            // Solo actualizamos la interfaz si hay un cambio real de expresión para evitar "parpadeo" (flicker) de actualizaciones DOM constantes
            if (dominant !== lastExpression) {
                lastExpression = dominant;
                updateUI(dominant);
                
                // Integración con Arduino Lab: Si la función sendEmotion existe (de app.js), llamarla

              sendEmotion(dominant)
                if (typeof sendEmotion === 'function') {
                    // Los eventos esperados por tu sistema son 'happy', 'sad', 'neutral', 'angry', 'ur'
                    // face-api detecta 'happy', 'sad', 'neutral', 'angry', 'surprised', 'disgusted', 'fearful'
                    const allowedEmotions = ['happy', 'sad', 'neutral', 'angry'];
                    if (allowedEmotions.includes(dominant)) {
                        sendEmotion(dominant);
                    }
                }
            }
        } else {
            // Si se pierde la detección por 1 frame no borramos todo de inmediato, esperamos ~1.5 segundos
            noFaceFrames++;
            if (noFaceFrames > 3) {
              sendEmotion('ur');
                lastExpression = null;
                currentExpressionSpan.innerText = "No se detecta rostro";
              sendEmotion('ur');
                document.querySelectorAll('.exp-btn').forEach(btn => btn.classList.remove('active'));
            }
        }
    }, 50); // Actualización cada 150ms
});

// Actualizar la interfaz con la expresión detectada
function updateUI(expression) {
    const mappedData = expressionsMap[expression];
    
    if (mappedData) {
        // Actualizar texto
        currentExpressionSpan.innerText = mappedData.text;
        
        // Actualizar estado de los botones (iluminar el correspondiente)
        document.querySelectorAll('.exp-btn').forEach(btn => btn.classList.remove('active'));
        if (mappedData.btnId) {
            const btn = document.getElementById(mappedData.btnId);
            if (btn) btn.classList.add('active');
        }
    }
}

// Iniciar proceso
loadModels();
