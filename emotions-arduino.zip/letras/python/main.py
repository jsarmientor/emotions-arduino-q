from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI

ui = WebUI()

def on_emotion(client, data):
    emotion = data.get("emotion")
    if emotion:
        Bridge.call("set_emotion", emotion)

ui.on_message("set_emotion", on_emotion)

App.run()
