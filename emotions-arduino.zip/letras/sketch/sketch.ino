#include <Arduino_LED_Matrix.h>
#include <Arduino_RouterBridge.h>

Arduino_LED_Matrix matrix;

// Estructura de 8 filas x 13 columnas (Mapeo visual directo)
// Estilo: Robot Rectangular Clásico

// 🤖 ROBOT FELIZ
uint8_t happy_map[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0, // Borde superior
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,1,1,0,0,0,0,0,1,1,0,0, // Ojos cuadrados
  0,0,1,1,0,0,0,0,0,1,1,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,1,0,0,0,0,0,0,0,1,0,0, // Comisuras
  0,0,0,1,1,1,1,1,1,1,0,0,0, // Boca sonriente
  0,0,0,0,0,0,0,0,0,0,0,0,0  // Borde inferior
};

// 🤖 ROBOT TRISTE
uint8_t sad_map[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,1,1,0,0,0,0,0,1,1,0,0, // Ojos cuadrados
  0,0,1,1,0,0,0,0,0,1,1,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,1,1,1,1,1,0,0,0,0, // Boca triste (curva arriba)
  0,0,0,1,0,0,0,0,0,1,0,0,0, // Comisuras hacia abajo
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

// 🤖 ROBOT NEUTRAL
uint8_t neutral_map[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,1,1,0,0,0,0,0,1,1,0,0,
  0,0,1,1,0,0,0,0,0,1,1,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,1,1,1,1,1,1,1,0,0,0, // Línea recta
  0,0,0,0,0,0,0,0,0,0,0,0,0
};

// 🤖 ROBOT ENOJADO
uint8_t angry_map[104] = {
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,1,0,0,0,0,0,0,0,0,0,1,0, // Cejas bajas
  0,0,1,1,0,0,0,0,0,1,1,0,0,
  0,0,1,1,0,0,0,0,0,1,1,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,1,1,1,1,1,1,1,0,0,0, // Boca tensa
  0,0,1,1,1,1,1,1,1,1,1,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0
};


// 🎓 LOGO UNIVERSIDAD DEL ROSARIO (UR)
uint8_t ur_map[104] = {
  0,0,1,0,1,0,0,0,0,1,1,0,0, // Marco
  0,0,1,0,1,0,0,0,1,0,0,1,0, // U      R
  0,0,1,0,1,0,0,0,1,0,1,0,0, // U      R R
  0,0,1,0,1,0,0,0,1,1,0,0,0, // U      R R
  0,0,1,0,1,0,0,0,1,0,1,0,0, // U      R  R
  0,0,0,1,1,0,0,0,1,0,0,1,0, //  UU    R   R
  0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0  // Marco
};

void set_emotion(String emotion) {
  emotion.trim();
  emotion.toLowerCase();

  if (emotion == "happy") matrix.draw(happy_map);
  else if (emotion == "sad") matrix.draw(sad_map);
  else if (emotion == "neutral") matrix.draw(neutral_map);
  else if (emotion == "angry") matrix.draw(angry_map);
  else if (emotion == "ur") matrix.draw(ur_map);
}

void setup() {
  matrix.begin();
  matrix.setGrayscaleBits(1); 

  Bridge.begin();
  Bridge.provide("set_emotion", set_emotion);

  matrix.draw(happy_map); // Inicia con robot feliz
}

void loop() {
  // Bridge maneja la comunicación con tu script de Python
}